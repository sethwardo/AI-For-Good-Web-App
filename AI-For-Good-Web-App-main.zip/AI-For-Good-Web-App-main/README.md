# AI-for-Good
AI for Good 496 Project

For docker website - http://localhost:8000/

The database is connected now and Dr. Chang has given some input on how to slim down the files so it's more streamlined for now. 

To connect to the database use the username and password displayed in the run.py folder. 

Use MySQL workbench or an equivalent to access the database and copy and paste the init.sql file in the app folder down to where it says and run the query to populate the database. Once this is done the ID's and Article names shall be shown on the screen.

If you have any problems please reach out on the google chat.

Network Graph documentation: https://visjs.github.io/vis-network/docs/network/